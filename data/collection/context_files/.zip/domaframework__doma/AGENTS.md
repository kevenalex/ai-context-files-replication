# AGENTS.md

This file provides guidance to AI coding agents when working with code in this repository.

## Instruction Scope

These repository-level instructions apply to the entire project. Some modules may contain their own `AGENTS.md` files with additional scoped guidance. When working under a module directory, follow both this file and the module-specific instructions.

## Project Overview

Doma is a database access framework for Java 17+ that uses compile-time annotation processing. It provides type-safe database operations through a Criteria API and SQL templates ("two-way SQL"). The project is organized into multiple modules with comprehensive integration testing across various databases.

## Build Commands

### Core Development
- `./gradlew build` - Build all modules with Spotless formatting applied
- `./gradlew test` - Run tests for all modules (defaults to H2 database)
- `./gradlew spotlessApply` - Apply code formatting (automatically runs with build)
- `./gradlew spotlessCheck` - Check code formatting compliance

### Testing with Different Databases
The project supports extensive database testing. Tests can be run against specific databases:
- `./gradlew h2` - Run tests against H2 (in-memory)
- `./gradlew mysql` - Run tests against MySQL 5.7 (via Testcontainers)
- `./gradlew mysql8` - Run tests against MySQL 8.0 (via Testcontainers)
- `./gradlew oracle` - Run tests against Oracle 21c (via Testcontainers)
- `./gradlew postgresql` - Run tests against PostgreSQL 12 (via Testcontainers)
- `./gradlew sqlite` - Run tests against SQLite
- `./gradlew sqlserver` - Run tests against SQL Server 2019 (via Testcontainers)
- `./gradlew testAll` - Run tests against all supported databases

### Single Test Execution
To run a specific test class:
```bash
./gradlew :module-name:test --tests "ClassName"
# Example: ./gradlew :doma-core:test --tests "ConfigTest"
```

To run integration tests:
```bash
./gradlew :integration-test-java:test --tests "TestClassName"
```

### Choosing Verification Commands
- Documentation-only changes: run `./gradlew spotlessApply`.
- Changes under `doma-core`: run `./gradlew :doma-core:test`.
- Changes under `doma-processor`: run `./gradlew :doma-processor:test`; for compiler-sensitive changes, also run `./gradlew :doma-processor:test -Pcompiler=ecj`.
- Integration behavior changes: run the relevant integration test module or database task; reserve `./gradlew testAll` for broad cross-database impact.

## Module Architecture

### Core Modules
- **doma-core**: Main framework containing annotations, JDBC abstractions, query builders, and type system
- **doma-processor**: Annotation processor that generates metamodel classes and validates SQL at compile time
- **doma-kotlin**: Kotlin-specific extensions and integration
- **doma-slf4j**: SLF4J logging integration
- **doma-template**: SQL template processing utilities
- **doma-mock**: Test utilities and mocks

### Integration Test Modules
- **integration-test-common**: Shared test infrastructure and configuration
- **integration-test-java-common**: Common Java test utilities
- **integration-test-java**: Java-based integration tests
- **integration-test-kotlin**: Kotlin-based integration tests

## Key Architectural Concepts

### Annotation Processing Pipeline
The framework heavily relies on compile-time code generation. The `doma-processor` module generates:
- Entity metamodel classes (ending with `_`)
- DAO implementation classes
- SQL validation and type checking

### SQL Template System ("Two-way SQL")
SQL files use special comments for dynamic SQL that remain valid SQL when run directly:
- `/*%if condition*/` - Conditional blocks
- `/*parameter*/'default'` - Parameter binding
- `/*%expand*/` - Column expansion

### Type System Hierarchy
- **Wrappers** (`org.seasar.doma.wrapper`): Low-level JDBC type mappings
- **Domain Types** (`org.seasar.doma.jdbc.domain`): Custom value object mappings
- **Entity Types** (`org.seasar.doma.jdbc.entity`): ORM entity mappings
- **Criteria API** (`org.seasar.doma.jdbc.criteria`): Type-safe query building

### Configuration System
- `Config` interface defines database connection, naming conventions, dialects
- `SimpleConfig` provides basic implementation
- Dialect classes handle database-specific SQL generation

## Development Guidelines

### Setting Up Development Environment
- Install JDK 17 (recommended via [SDKMAN](https://sdkman.io/jdks))
- Clone repository: `git clone https://github.com/domaframework/doma.git`
- Build project: `./gradlew build`
- For IDE setup, import as a Gradle project (IntelliJ IDEA recommended)

### Annotation Processing Configuration
When modifying annotation processors or entity/domain classes, the `ap` property in `gradle.properties` can be used to pass additional annotation processor options in CSV format.

### Code Formatting
All code must pass Spotless formatting checks. The build automatically applies formatting, but you can run `./gradlew spotlessCheck` to verify compliance before committing.

**IMPORTANT**: Always run `./gradlew spotlessApply` before committing changes to ensure consistent code formatting across the project.

### Import Statement Guidelines
- Do not use wildcard imports (e.g., `import java.util.*;`) in Java code
- Always use explicit imports for each class (e.g., `import java.util.List;`, `import java.util.Map;`)
- This improves code readability and makes dependencies explicit

### Contributing Guidelines
- Submit contributions via GitHub Pull Requests from your own fork
- Write Git commit messages, GitHub Pull Request titles, and GitHub Pull Request descriptions in English
- Write issues and PRs in English for broader accessibility
- All contributions are licensed under Apache License 2.0

### Integration Test Structure
Integration tests use Testcontainers for database provisioning. Database URLs are configured in `gradle.properties` with the `TC_DAEMON=true` flag to improve test performance by reusing containers.

## Documentation

### Documentation System
The project uses Sphinx for documentation generation, hosted on ReadTheDocs:
- **Source**: Documentation source files are in the `docs/` directory
- **Format**: Written in Markdown (`.md`) format
- **Languages**: English and Japanese (full translation support)
- **URL**: https://docs.domaframework.org/

### Documentation Structure
- **Getting Started**: Setup guide and quickstart (`getting-started.rst`)
- **Core Concepts**: Entity, Domain, DAO, Embeddable documentation
- **Query Operations**: Comprehensive guides for all database operations in `query/` subdirectory
- **Query Building**: Query DSL, SQL templates documentation
- **Framework Integration**: Spring Boot, Quarkus, Lombok, Kotlin support guides
- **Development**: Build configuration, annotation processing, code generation

### Building Documentation Locally

#### Using Python Virtual Environment

```bash
# Create virtual environment
python -m venv .venv

# Activate virtual environment (on macOS/Linux)
source .venv/bin/activate

# Go to docs directory
cd docs

# Install dependencies in virtual environment
pip install -r requirements.txt
```

#### Generate HTML documentation with auto-reload
```bash
source .venv/bin/activate && \
cd docs && \
sphinx-autobuild . _build/html && \
cd ..
# Visit http://127.0.0.1:8000
```

#### Generate HTML documentation with auto-reload (language=ja)
```bash
source .venv/bin/activate && \
cd docs && \
sphinx-autobuild . _build/html -Dlanguage=ja&& \
cd ..
# Visit http://127.0.0.1:8000
```

#### Update Japanese translation files
```bash
source .venv/bin/activate && \
cd docs && \
sphinx-build -b gettext . _build/gettext && \
sphinx-intl update -p _build/gettext -l ja && \
cd ..
```

### Documentation Guidelines
- Verify Markdown syntax and rendering before submitting PRs
- Maintain consistency with existing documentation style
- Update both English and Japanese translations when applicable
- Test documentation builds locally using `sphinx-autobuild`

### LLM-Friendly Documentation
The project includes `docs/llms.txt`, a comprehensive overview designed for AI/LLM consumption. This file provides:
- Concise project summary and key features
- Complete architecture overview with all modules
- Links to all major documentation sections
- Use case examples and integration guides
This resource helps AI assistants quickly understand Doma's capabilities and structure
