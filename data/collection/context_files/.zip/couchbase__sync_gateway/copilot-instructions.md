When performing a code review, if there are any changes to the REST APIs (e.g. REST handler code, query parameters, structs returned via handler functions), ensure the OpenAPI specifications are updated accordingly in the `docs/api` directory.

When performing a code review, if there is any dev-time logging using `log.Printf`, `fmt.Printf`, or similar, ensure it is removed or replaced with appropriate Sync Gateway logging (e.g. `base.Infof`, `base.Warnf`, `base.Debugf`).

When performing a code review, if a log message includes User Data, ensure the value is wrapped with the `base.UD()` helper function to enable redaction. User Data includes: Document IDs, JSON document contents (keys and values), usernames, email addresses, or other personally identifiable information (PII).

When performing a code review, be mindful of performance implications, such as mutex contention, race conditions, and other concurrency-related issues.

When performing a code review, ensure code comments explain the _intent_ or _reasoning_ behind an implementation, rather than just restating what the code does.

When performing a code review, ensure `for` loops have sufficient exit conditions and are not prone to infinite loops. Prefer expressing the exit condition in the loop declaration itself, rather than relying on `break` statements within the loop body.

When performing a code review, make sure context.WithCancelCause is used instead of context.WithCancel.

When performing a code review, flag any new code that gates behavior on whether xattrs are enabled (e.g. `UseXattrs` checks, non-xattr write/read branches, or config plumbing that exposes xattr-mode as a choice). Since Sync Gateway 4.0, xattr mode is the only supported mode on `main`; new code must assume xattrs are enabled. The exception is read-side migration logic that handles pre-existing non-xattr documents already in a bucket — that gradual-migration path must still be preserved, but no new write paths or config surfaces should produce non-xattr data.
